The files in this charts folder are necessary only for Vaadin 6
(in Vaadin 7 these files are already included in the library jar).
Copy the content of this folder (except readme.txt) to WebContent/VAADIN/charts


